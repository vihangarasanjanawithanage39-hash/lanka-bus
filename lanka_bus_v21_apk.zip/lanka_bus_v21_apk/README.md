# 🚌 Lanka Bus — Sri Lanka Bus Schedule, Live Trip Tracker & Map (Android APK + Web PWA)

## 📱 GitHub වලින් නොමිලේ Android APK එක හදාගන්නා පියවර

1. **GitHub Repository එකක් හදන්න:** https://github.com/new වෙත ගොස් අලුත් **Public** repository එකක් හදන්න (උදා: `lanka-bus-app`).
2. **ZIP එක Extract කරලා Upload කරන්න:**
   - මේ `lanka_bus_github_apk.zip` ගොනුව Extract (Unzip) කරන්න.
   - Repository එකේ **Add file ➔ Upload files** ඔබලා Extract කළ folder එක ඇතුළේ ඇති සියලුම files (`package.json`, `capacitor.config.json`, `www/`, `.github/`) upload කරලා **Commit changes** ඔබන්න.
   - *වැදගත්:* `.github` folder එක hidden නිසා upload නොවුණොත්, GitHub එකේ **Add file ➔ Create new file** ඔබලා නම `.github/workflows/build-apk.yml` කියලා දීලා workflow code එක paste කරන්න.
3. **Actions Tab එකෙන් APK එක Download කරන්න:**
   - Repo එකේ **Actions** tab එකට යන්න. `Build Lanka Bus Android APK` workflow එක ස්වයංක්‍රීයව run වෙලා විනාඩි 3–4කින් කොළ පාට ✅ වෙයි.
   - ඒක ඇතුළට ගිහින් **Artifacts** යටතේ ඇති **`LankaBus-Android-APK`** download කරලා phone එකේ install කරගන්න!
